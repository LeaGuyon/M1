void erreur();
void setup_input_capture();
float measure_clock_error();
