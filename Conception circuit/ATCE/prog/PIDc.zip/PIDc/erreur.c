#include <avr/io.h>
#include <avr/interrupt.h>
#define F_CPU 16000000UL  // Fréquence CPU présumée

volatile struct {
    uint32_t start_cycles;
    uint32_t end_cycles;
    uint8_t measurement_ready;
} timing = {0};

// Configuration du Timer1 pour capture sur PD4 (ICP1)
void setup_input_capture() {
    TCCR1A = 0;
    TCCR1B = (1 << ICES1) |
             (1 << CS10);     // pas de préscaler ?
    TIMSK1 = (1 << ICIE1);
}

ISR(TIMER1_CAPT_vect) {
    static uint8_t first_capture = 1;
    
    if(first_capture) {
        timing.start_cycles = ICR1;
        first_capture = 0;
    } else {
        timing.end_cycles = ICR1;
        timing.measurement_ready = 1;
        first_capture = 1;
    }
}

float measure_clock_error() {
    // Réinitialisation protégée (le main gère cli()/sei())
    timing.measurement_ready = 0;
    
    setup_input_capture();
    
    // Attente synchrone
    while(!timing.measurement_ready);
    
    // Lecture séquentielle (safe car ISR ne modifie que quand measurement_ready=1)
    uint32_t cycles_measured = timing.end_cycles - timing.start_cycles;
    
    // Calcul erreur en ppm (parties par million)
    return ((float)cycles_measured - F_CPU) / F_CPU * 1e6;
}
