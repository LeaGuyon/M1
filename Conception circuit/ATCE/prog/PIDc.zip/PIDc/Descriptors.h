void Descriptors();
void setup_input_capture();
void setup_reference_timer();
int16_t measure_frequency_error();
