float PID(float consigne, float freq_mesure);
void sature_integrale(float *integrale);
float sature_commande(float commande);
