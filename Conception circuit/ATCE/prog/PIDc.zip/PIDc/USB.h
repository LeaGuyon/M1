#include <stdint.h>
void USB(uint32_t freq_error);
